package com.thangcao.tripsviet.ultil;

public class Server {
   public static String localhost = "http://thangminhcao.000webhostapp.com/tripsviet/";

//    public static String localhost = "http://192.168.1.9/tripsviet/";

    public static String checkaccount = localhost + "checkaccout.php";
   public static String checkfollow = localhost + "checkfollow.php";
   public static String addfollow = localhost + "addfollow.php";
    public static String register = localhost + "register.php";
    public static String resetpw = localhost + "resetpw.php";
    public static String login = localhost + "login.php";
    public static String province = localhost + "getprovince.php";
    public static String district = localhost + "getdistrict.php";
    public static String ward = localhost + "getward.php";
    public static String getuserinfo = localhost + "getuserinfo.php";
    public static String updateuserinfo = localhost + "updateuserinfo.php";
    public static String noupdateuserinfo = localhost + "noupdateuserinfo.php";
    public static String updateuserinfoonlyimg = localhost + "updateuserinfoonlyimg.php";
    public static String updateuserinfoonlycv = localhost + "updateuserinfoonlycv.php";
    public static String addPost = localhost + "addPost.php";
    public static String getPost = localhost + "getPost.php";
    public static String getNameplace = localhost + "getNameplace.php";
    public static String getPostById = localhost + "getPostById.php";
    public static String getPostByNamePlace = localhost + "getPostByNamePlace.php";
    public static String getPostByFollow = localhost + "getPostByFollow.php";
    public static String addreact = localhost + "addreact.php";
    public static String getStatusReact = localhost + "getStatusReact.php";
    public static String getTotalLike = localhost + "getTotalLike.php";
    public static String addcommnent = localhost + "addcomment.php";
    public static String getComment = localhost + "getComment.php";
    public static String getCommentDesc = localhost + "getCommentDesc.php";
    public static String getPostByPhoneUser = localhost + "getPostByPhoneUser.php";
    public static String imagesget = localhost + "images/";
    public static String userget =  localhost + "users/";
    public static String provinceget =  localhost + "provinces/";
    public static String getUnApprovedPost =  localhost + "getPost_notBrowseByUser.php";
    public static String getProvinceById =  localhost + "getProvinceById.php";
    public static String getPostByNameProvince =  localhost + "getPostByNameProvince.php";
    public static String getPostByNameDistrict =  localhost + "getPostByNameDistrict.php";
    public static String addRateapp =  localhost + "addRateapp.php";
}
